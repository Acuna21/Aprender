#Ejercico 3:Hacer un programa para intercambiar el valor de 2 variables. 
a=int(input("Ingrese un número a: "))
b=int(input("Ingrese un número b: "))
a,b=b,a

print(f"El intercambio de variables es: a= {a} y b= {b}")


#Forma 2
a1=int(input("Ingrese un número a1: "))
b1=int(input("Ingrese un número b1: "))

aux=a1
aux2=b1

print(f"El nuevo valor de a es: {aux2}")
print(f"El nuevo valor de b es: {aux}")

