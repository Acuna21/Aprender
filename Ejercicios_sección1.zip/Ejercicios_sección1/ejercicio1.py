#Ejercico 1: Escribir la siguiente expresión en forma de expresión algoritmica. 
a=int(input("Ingrese su valor: "))
b=int(input("Ingrese su valor: "))
c=int(input("Ingrese su valor: "))

resultado=(((a**3)*((b**2)-2*a*c))/(2*b))
print(f"El resultado es{resultado}")