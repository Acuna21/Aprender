#Ejercico 1: Determinar la solución lógica de la siguiente operación. 
a=int(input("Ingrese un número a: "))
b=int(input("Ingrese un número b: "))
resul=((3+5*8)<3) and ((((-6/3)*4+2)<2)) or (a>b)
print(f"Su solución lógica es: ", resul)